package com.example.feedback;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.RatingBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
TextView stars;
RatingBar rbstars;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        stars = findViewById(R.id.stars);
        rbstars = findViewById(R.id.rbstars);
        rbstars.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if(rating==0)
                {
                    stars.setText("No rating");
                }
                else if(rating==1)
                {
                    stars.setText("Very Dissatisfied");
                }
                else if( rating==2)
                {
                    stars.setText("Dissatisfied");
                }
                else if( rating==3)
                {
                    stars.setText("Ok");
                }
                else if(rating ==4)
                {
                    stars.setText("Satisfied");
                }
                else if(rating==5)
                    stars.setText("Very Satisfied");
            }
        });
    }
}